# cc.py
import re

_check_hex_color = re.compile("#[A-Fa-f0-9]{6}")

fp1 = open("cc1.txt", "wt")
with open("color.py", "rt") as fp2:
    for ll in fp2:
        match = _check_hex_color.search(ll)
        if match:
            c1 = ll.split(' ')
            fp1.write("%s = Color(0x%s,0x%s,0x%s)\n"%(c1[0], c1[1][1:3], c1[1][3:5], c1[1][5:7]))
        

fp1.close()        
