# Vector Graphic Library (VGL) for Python
#
# cval.py
#
# 2020-12-12 Ver 0.1
#
# Author: Uisang Hwang
# Email : uhwangtx@gmail.com
#

_VIEW_MODE_NONE = 0
_VIEW_MODE_XY   = 1
_VIEW_MODE_2D   = 1
_VIEW_MODE_3D   = 2

