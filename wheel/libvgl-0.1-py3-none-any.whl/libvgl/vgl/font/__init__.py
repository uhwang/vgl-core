# __init__.py
__version__ = '0.1'
__VERSION__ = __version__




