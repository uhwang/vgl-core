# Vector Graphic Library (VGL) for Python
#
# vector.py
#
# 2020-2-19 Ver 0.1
#
# Author: Uisang Hwang
# Email : uhwangtx@gmail.com
#

#class vector2d:
#	def __init__(self, x,y):
#		self.x = x
#		self.y = y
#		
#	def __add__()