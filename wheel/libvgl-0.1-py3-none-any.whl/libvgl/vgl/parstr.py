'''
parstr.py

parse string and create fontmap list

8/1/2023

'''

from . import fontid
from . import fontm

def parse_string(txt):
    pass