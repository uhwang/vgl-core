# dragon_curve.py

import libvgl as vgl
import numpy as np

xx, yy = 5,5
fmm = vgl.FrameManager()
frm = fmm.create(1,1,4,4, vgl.Data(-xx, xx, -yy, yy))

d_list = list()

def create_dragon(dev, d1, level):
    
    dev.polyline(d1.get_xs(), d1.get_ys())
    if level > 0:
        d2  = d1.copy().rotate(-90)
        x,y = d1.firstpoint()
        d3  = d1.join(d2.trans(x,y))
        x,y = d3.endpoint()
        d3.trans(x,y)
        create_dragon(dev, d3, level-1)

def find_range(d_list):
    xmin, xmax, ymin, ymax = 1000, -1000, 1000, -1000
    for d1 in d_list:
        dxmin = d1.xmin()
        dxmax = d1.xmax()
        dymin = d1.ymin()
        dymax = d1.ymax()
        
        if xmin > dxmin: xmin = dxmin
        if xmax < dxmax: xmax = dxmax
        if ymin > dymin: ymin = dymin
        if ymax < dymax: ymax = dymax
        
    return xmin, xmax, ymin, ymax
        
def save():
    level = 2
    d1 = vgl.vertex.Vertex(2, src=[0,0,0.5,0])
    
    #create_dragon(d, level)
    
    #xmin, xmax, ymin, ymax =find_range(d_list)
    #print(find_range(d_list))
    
    dev_img = vgl.DeviceIMG("dragon.jpg", fmm.get_gbbox(), 300)
    dev_img.set_device(frm)    
        
    create_dragon(dev_img, d1, level)
    vgl.draw_axis(dev_img)
    dev_img.close()
    
if __name__ == "__main__":
    save()