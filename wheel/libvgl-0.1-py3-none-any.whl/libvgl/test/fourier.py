import numpy as np
import libvgl as vgl
fmm = vgl.FrameManager()
glyp_lines = vgl.fontutil.glyp_to_line(vgl.fontid.FONT_SYMBOL, 0x64)
data = vgl.Data(glyp_lines[1]*1.1, 
                glyp_lines[2]*1.1, 
                glyp_lines[3]*1.1, 
                glyp_lines[4]*1.2)
nlines = len(glyp_lines[0])
frm = fmm.create(1,1,6,6, data)
gbox = fmm.get_gbbox()
ctbl = vgl.color.create_color_table(0,300, 0.8, 1, nlines)
xps, yps = glyp_lines[0][3][0], glyp_lines[0][3][1]
N = xps.size
fcx = np.fft.fft(xps)
fcy = np.fft.fft(yps)
pntx, pnty = np.zeros(N), np.zeros(N)

def draw_fft(dev):
    #for n in range(N):
    #    for k in range(N):
    #        pntx[n] += fcx[k]*np.exp(2j*np.pi*k*n/N)/N
    #        pnty[n] += fcy[k]*np.exp(2j*np.pi*k*n/N)/N

    # https://www.robots.ox.ac.uk/~sjrob/Teaching/SP/l7.pdf
    # p87
    for n in range(N):
        for k in range(N):
            phi = 2*np.pi*k*n/N
            pntx[n]+=(np.real(fcx[k])*np.cos(phi)-np.imag(fcx[k])*np.sin(phi))/N
            pnty[n]+=(np.real(fcy[k])*np.cos(phi)-np.imag(fcy[k])*np.sin(phi))/N


    dev.set_device(frm, extend=vgl.device._FIT_DEPENDENT)

    for i, gl in enumerate(glyp_lines[0]):
        dev.polyline(gl[0], gl[1], lthk=0.02, lcol=ctbl[i])

    dev.polyline(pntx, pnty, lthk=0.005, lcol=vgl.color.GREEN, 
                 lpat=vgl.linepat.get_stock_dash())
    vgl.draw_center_axis(dev)
    dev.close()

fps=2
duration = N/fps
dtheta = 2*np.pi/duration
theta = 0
glyp_track_x = []
glyp_track_y = []

def animate_fft(t):
    global dev, theta, glyp_track_x, glyp_track_y
    dev.fill_white()
    x0, y0 = 0, 0
    for k in range(N):
        x1 = np.abs(fcx[k])*np.cos(theta*k*2*np.pi/N)
        y1 = np.abs(fcy[k])*np.sin(theta*k*2*np.pi/N)
        rr = np.sqrt((x1-x0)**2+(y1-y0)**2)
        dev.line(tx,ty,tx+x1,ty+y1,vgl.color.GRAY20, 0.003)
        dev.circle(tx,ty,rr, vgl.color.RED, 0.003)
        glyp_track_x.append(x1)
        glyp_track_y.append(y1)
        tx += x1
        ty += y1
    dev.polyline(glyp_track_x,glyp_track_y,vgl.color.BLACK, 0.005)
    theta += dtheta

def movie_fft():
    global dev
    dev = vgl.DeviceIMG("", gbox, 200)
    dev.set_device(frm, extend=vgl.device._FIT_DEPENDENT)
    dev_ani = vgl.DeviceCairoAnimation("fourier.mp4", dev, animate_fft, fps=fps, 
                                       duration=duration)
    dev_ani.save_video()

def save():
    dev = vgl.DeviceIMG("fourier.jpg", gbox, 200)
    draw_fft(dev)

if __name__ == "__name__":
    #save()
    movie_fft()