#from scipy.fft import fft, fftfreq
import numpy as np
import libvgl as vgl

fmm = vgl.FrameManager()
glyp_lines = vgl.fontutil.glyp_to_line(vgl.fontid.FONT_SYMBOL, 0x64)
data = vgl.Data(glyp_lines[1]*1.1, 
                glyp_lines[2]*1.1, 
                glyp_lines[3]*1.1, 
                glyp_lines[4]*1.2)
frm = fmm.create(1,1,6,6, data)
gbox = fmm.get_gbbox()
ctbl = vgl.color.create_color_table(0,300, 0.8, 1, len(glyp_lines[0]))
xps, yps = glyp_lines[0][3][0], glyp_lines[0][3][1]

def draw(dev):
    dev.set_device(frm, extend=vgl.device._FIT_DEPENDENT)
    #vgl.draw_center_axis(dev)
    vgl.draw_axis(dev)
    
    for i, gl in enumerate(glyp_lines[0]):
        dev.polyline(gl[0], gl[1], lthk=0.006, lcol=ctbl[i])
    dev.close()

def fft_draw():
    norm = xps.size//2
    ftx = np.fft.fft(xps)[:norm]
    fty = np.fft.fft(yps)[:norm]
    ftxn=np.abs(ftx)/norm
    ftyn=np.abs(fty)/norm

def save():
    #from . import chkfld
    import chkfld
    
    if not chkfld.create_folder("./fourier"):
        return
        
    dev_img = vgl.DeviceIMG("./fourier/rotation.jpg", gbox, 200)
    #dev_wmf = vgl.DeviceWMF("./rotation/rotation.wmf", gbox)
    #dev_emf = vgl.DeviceEMF("./rotation/rotation.emf", gbox)
    #dev_pdf = vgl.DevicePDF("./rotation/rotation.pdf", gbox)
    #dev_svg = vgl.DeviceSVG("./rotation/rotation.svg", gbox, 200)
    #dev_ppt = vgl.DevicePPT("./rotation/rotation.pptx",gbox)
    
    fft_draw()
    
    draw(dev_img)
    #draw(dev_wmf)
    #draw(dev_emf)
    #draw(dev_pdf)
    #draw(dev_svg)
    #draw(dev_ppt)
    
if __name__ == "__main__":
    save() 