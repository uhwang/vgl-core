__version__ = '0.1'
__VERSION__ = __version__

from .msg import message_box
