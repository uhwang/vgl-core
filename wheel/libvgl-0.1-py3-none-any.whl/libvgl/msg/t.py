# tpen.py

from libvgl.vgl import gdiobj
from libvgl.vgl import color

p = gdiobj.Pen()
p.lcol = color.RED
print(p)
#print(p)